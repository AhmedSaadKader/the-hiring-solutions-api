CREATE TYPE job_status AS ENUM ('open', 'closed', 'pending');
