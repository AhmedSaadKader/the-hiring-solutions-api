DROP TABLE candidates;
