DROP TYPE job_status;
