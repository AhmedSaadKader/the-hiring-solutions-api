DROP TABLE skills;
