DROP TABLE jobs;
