DROP TABLE applications;
